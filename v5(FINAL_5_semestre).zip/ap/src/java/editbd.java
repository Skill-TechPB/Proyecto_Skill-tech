/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import Conexion.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.servlet.http.HttpSession;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Josue
 */
@WebServlet(urlPatterns = {"/editbd"})
public class editbd extends HttpServlet {
    //Nuevas
    String[] prege = new String[10];
    String[] respe = new String[40];
    int[] valorei = new int[10];//Valore intermedio
    //Originales
    String[] preg = new String[10];
    String[] resp = new String[40];
    int[] valor = new int[10];
    //al obtener el valor del select se regresa como String, aqui se guarda y posteriormente se convierte en Int y se guarda en valorei
    String[] xd= new String[10];
    
    String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime());
    String error="";
    Statement stmt;
    ResultSet rs,rs2,rs3,rs4;
    int cont=0;
    int idpro=0;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            HttpSession session = request.getSession(true);
            try {
                    //Inicio de mi mamada
                    Conexion cn = new Conexion();
                    Connection con = cn.getConnection();
                    Class.forName("com.mysql.jdbc.Driver");
                    stmt = con.createStatement();
                    PreparedStatement insertStatement;
                    int idUsuario = (int) session.getAttribute("usu_id");
                    rs4 = stmt.executeQuery("select pro_id from profesor where usu_id="+idUsuario+"");
                    if(rs4.next()){
                    idpro=rs4.getInt("pro_id");
                        }
                    
                    //Se obtienen los arreglos de las preguntas y respuestas originales
                    rs = stmt.executeQuery("select pgt_pregunta from pregunta where for_id=2");
                    cont=0;
                    while(rs.next()){
                    preg[cont] =rs.getString("pgt_pregunta");
                    cont=cont+1;
                    }
                    cont=0;
                    rs2 = stmt.executeQuery("select respuesta.rpt_respuesta from pgt_rpt inner join pregunta on pregunta.pgt_id=pgt_rpt.pgt_id inner join formulario on formulario.for_id=pregunta.for_id inner join respuesta on respuesta.rpt_id=pgt_rpt.rpt_id where formulario.for_id=2");
                    //Pregunta
                    while(rs2.next()){
                    resp[cont] = rs2.getString("respuesta.rpt_respuesta");
                    cont=cont+1;
                    }
                    cont=0;
                    //Por si la duda, aqui se obtienen los id de las respuestas correctas
                    rs3 = stmt.executeQuery("select respuesta.rpt_id from pgt_rpt inner join pregunta on pregunta.pgt_id=pgt_rpt.pgt_id inner join formulario on formulario.for_id=pregunta.for_id inner join respuesta on respuesta.rpt_id=pgt_rpt.rpt_id where formulario.for_id=2 and rpt_valor=1;");
                    //valor id
                    while(rs3.next()){
                    valor[cont] = rs3.getInt("respuesta.rpt_id");
                    cont=cont+1;
                    }
                    cont=0;
                    
                    //Se obtienen los arreglos de las modificaciones de preguntas y respuestas y se comparan con las originales
                    //pregunta
                    for(int i=0; i<prege.length;i++){
                    prege[i]=request.getParameter("editable"+String.valueOf(i+1));
                    if(prege[i].equals(preg[i])==true || prege[i]==""){
                    }else{
                    insertStatement = con.prepareStatement("update pregunta set pgt_pregunta=? where pgt_id=?;");
                    insertStatement.setString(1, prege[i]);
                    insertStatement.setInt(2, i+11);
                    insertStatement.executeUpdate();
                    //bitacora
                    insertStatement = con.prepareStatement("insert into bitacora(pro_id, bit_fchmod, for_id, elf_id, bit_origen, bit_cambio) values(?,?,?,?,?,?)");
                    insertStatement.setInt(1, idpro);
                    insertStatement.setString(2, timeStamp);
                    insertStatement.setInt(3, 2);
                    insertStatement.setInt(4, 1);
                    insertStatement.setString(5, preg[i]);
                    insertStatement.setString(6, prege[i]);
                    insertStatement.executeUpdate();
                    }
                    }
                    //respuesta
                    for(int i=0; i<respe.length;i++){
                    respe[i]=request.getParameter("respedit"+String.valueOf(i+1));
                    if(respe[i].equals(resp[i])==true || respe[i]==""){
                    }else{
                    insertStatement = con.prepareStatement("update respuesta set rpt_respuesta=? where rpt_id=?;");
                    insertStatement.setString(1, respe[i]);
                    insertStatement.setInt(2, i+41);
                    insertStatement.executeUpdate();
                    //bitacora
                    insertStatement = con.prepareStatement("insert into bitacora(pro_id, bit_fchmod, for_id, elf_id, bit_origen, bit_cambio) values(?,?,?,?,?,?)");
                    insertStatement.setInt(1, idpro);
                    insertStatement.setString(2, timeStamp);
                    insertStatement.setInt(3, 2);
                    insertStatement.setInt(4, 2);
                    insertStatement.setString(5, resp[i]);
                    insertStatement.setString(6, respe[i]);
                    insertStatement.executeUpdate();
                    }
                    }
                    
                    //inicio de valores
                    //Se resetean los valores de las respuestas
                    for(int i=0; i<resp.length;i++){
                    insertStatement = con.prepareStatement("update respuesta set rpt_valor='0' where rpt_id=?;");
                    insertStatement.setInt(1, i+41);
                    insertStatement.executeUpdate();
                    }
                    //Se obtienen los valores nuevo y se vuelven a meter los que no se modificaron
                    for(int i=0; i<prege.length;i++){
                    xd[i]=request.getParameter("select"+String.valueOf(i+1));
                    if( xd[i]==null || xd[i]=="" ){
                    insertStatement = con.prepareStatement("update respuesta set rpt_valor=? where rpt_id=?;");
                    insertStatement.setString(1, "1");
                    insertStatement.setInt(2, valor[i]);
                    insertStatement.executeUpdate();
                    }else{
                    valorei[i]=Integer.parseInt(xd[i]);
                    insertStatement = con.prepareStatement("update respuesta set rpt_valor=? where rpt_id=?;");
                    insertStatement.setString(1, "1");
                    insertStatement.setInt(2, valorei[i]);
                    insertStatement.executeUpdate();
                    //bitacora
                    insertStatement = con.prepareStatement("insert into bitacora(pro_id, bit_fchmod, for_id, elf_id, bit_origen, bit_cambio) values(?,?,?,?,?,?)");
                    insertStatement.setInt(1, idpro);
                    insertStatement.setString(2, timeStamp);
                    insertStatement.setInt(3, 2);
                    insertStatement.setInt(4, 3);
                    insertStatement.setInt(5, valor[i]);
                    insertStatement.setInt(6, valorei[i]);
                    insertStatement.executeUpdate();
                    }
                    }
                    //fin de valores
                    } catch (ClassNotFoundException | SQLException ex) {
                        error = "Error al registrar/actualizar los datos: " + ex.getMessage();
                        response.setContentType("text/html;charset=UTF-8");
                        response.sendRedirect("FEDITBD.jsp");
                    }
        response.setContentType("text/html;charset=UTF-8");
        response.sendRedirect("Editform.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
