/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import Conexion.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author olthek
 */
@WebServlet(urlPatterns = {"/TokenServlet"})
public class TokenServlet extends HttpServlet {
String error, token;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException {
        HttpSession session = request.getSession(true);
        token = request.getParameter("token");
        String TOK = (String) session.getAttribute("TK");
        int idUsuario = (int) session.getAttribute("usu_id");
        String anio = (String) session.getAttribute("anioegreso");

        if (validarToken(token)) {
            response.sendRedirect("teken.jsp");
            return;
        }

        if (token.equals(TOK)) {
            try {
                Conexion cn = new Conexion();
                Connection con = cn.getConnection();
                Class.forName("com.mysql.jdbc.Driver");
                PreparedStatement updateStatement = con.prepareStatement("UPDATE usuario SET usu_tk = ? WHERE usu_id = ?");
                updateStatement.setString(1, token);
                updateStatement.setInt(2, idUsuario);

                updateStatement.executeUpdate();

                PreparedStatement insertStatement = con.prepareStatement("INSERT INTO egresado(usu_id,egr_fch) values(?,?)");
                insertStatement.setInt(1, idUsuario);
                insertStatement.setString(2, anio);
                insertStatement.executeUpdate();

                response.sendRedirect("FPOO.jsp");
                return;
            } catch (ClassNotFoundException | SQLException ex) {
                error = "Error al registrar/actualizar los datos: " + ex.getMessage();
                response.sendRedirect("teken.jsp");
                return;
            }
        } else {
            response.sendRedirect("teken.jsp");
            error = "Los token no coinciden jajaja";
            return;
        }
    }

    public static boolean validarToken(String token) {
        String patron = "^[A-Z]{5}$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(token);
        return !matcher.matches();
    }
    
       // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    try {
        processRequest(request, response);
    } catch (SQLException ex) {
        Logger.getLogger(TokenServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    try {
        processRequest(request, response);
    } catch (SQLException ex) {
        Logger.getLogger(TokenServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
