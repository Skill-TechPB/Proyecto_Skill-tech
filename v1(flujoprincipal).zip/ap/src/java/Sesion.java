/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Conexion.Conexion;
import javax.servlet.annotation.WebServlet;

/*
 *
 */
@WebServlet(urlPatterns = {"/Sesion"})
public class Sesion extends HttpServlet {
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String error = "";
        ResultSet rs;
        String CorreoElec = request.getParameter("lemail");
        String Contra = request.getParameter("lpassword");
        String contraAdmin ="C0cT4L1@$";
        String correoadmin="admin13@gmail.com";
        int banderaAdmin = 1;
         
       if (CorreoElec.equals(correoadmin)&& Contra.equals(contraAdmin)){
            boolean create = true;
            HttpSession session = request.getSession(create);
            session.setAttribute("banderita",banderaAdmin);
            response.sendRedirect("admin.jsp");
        }else{
        try {
            Conexion cn = new Conexion();
            Connection con = cn.getConnection();
            Class.forName("com.mysql.jdbc.Driver");
            String consulta = "SELECT tpu_id, usu_id FROM usuario WHERE usu_email = ? AND usu_password= ?";
            PreparedStatement pst = con.prepareStatement(consulta);
            pst.setString(1, CorreoElec);
            pst.setString(2, Contra);
            rs = pst.executeQuery();
            boolean create = true;
            HttpSession session = request.getSession(create);
            
            session.setAttribute("email", CorreoElec);
            session.setAttribute("password", Contra);

            if (rs.next()) {
                // El usuario existe en la base de datos
                
                int userId = rs.getInt("usu_id");
                session.setAttribute("usu_id", userId);
                String tipodeusuario = rs.getString("tpu_id");
                session.setAttribute("tpu_id", tipodeusuario);
                  // Validar si el usuario tiene registro en la tabla profesor
                if(tipodeusuario.equals("1")){
                    String profesorConsulta = "SELECT usu_id FROM profesor WHERE usu_id = ?";
                PreparedStatement profesorPst = con.prepareStatement(profesorConsulta);
                profesorPst.setInt(1, userId);
                ResultSet profesorRs = profesorPst.executeQuery();
                
                if (profesorRs.next()) {
                    // El usuario tiene registro en la tabla profesor
                    response.sendRedirect("Editform.html");
                     profesorRs.close();
                     profesorPst.close();
                    }
                
                }else if(tipodeusuario.equals("2")){
                    response.sendRedirect("graficas.jsp");
                }
                else{
                    String egresadoConsulta = "SELECT usu_id FROM egresado WHERE usu_id = ?";
                PreparedStatement egresadoPst = con.prepareStatement(egresadoConsulta);
                egresadoPst.setInt(1, userId);
                ResultSet egresadoRs = egresadoPst.executeQuery();
                if (egresadoRs.next()) {
                    // El usuario tiene registro en la tabla egresado
                    //El usuario tiene registro en la tabla De POO
                String POOConsulta = "SELECT egr_id FROM resultadopo WHERE egr_id = ?";
                PreparedStatement POOPst = con.prepareStatement(POOConsulta);
               
                ResultSet POORs = POOPst.executeQuery();
                    if(POORs.next()){
                        response.sendRedirect("FBD.jsp");
                    }else{
                        response.sendRedirect("FPOO.jsp");
                    }
                    POORs.close();
                POOPst.close();
                egresadoRs.close();
                egresadoPst.close();
                
                }
                

                
                } 

                
               
                
            } else {
                // El usuario no existe en la base de datos
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html><body><h2>El usuario no existe en la base de datos</h2></body></html>");
            }

            rs.close();
            pst.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
         }
    }
}
