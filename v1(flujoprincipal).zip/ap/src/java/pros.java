/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import Conexion.Conexion;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author olthek
 */
@WebServlet(urlPatterns = {"/pros"})
public class pros extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String anioegreso = (String) request.getAttribute("anioegreso");
        String email = (String) request.getAttribute("email");
        String pasw = (String) request.getAttribute("pasw");
      try {
                    Conexion cn = new Conexion();
                    Connection con = cn.getConnection();
                    Class.forName("com.mysql.jdbc.Driver");
                    boolean create = true;
                    HttpSession session = request.getSession(create);
                    String consulta = "SELECT usu_id FROM usuario WHERE usu_email = ? AND usu_password= ?";
                    PreparedStatement pst = con.prepareStatement(consulta);
                    pst.setString(1, email);
                    pst.setString(2, pasw);
            ResultSet rs = pst.executeQuery();
                    if (rs.next()) {
                    int userId = rs.getInt("usu_id");
                    session.setAttribute("usu_id", userId);
                    session.setAttribute("anioegreso", anioegreso);
                    PreparedStatement insertStatement = con.prepareStatement("INSERT INTO egresado(usu_id, egr_fch) values(?,?)");
                    insertStatement.setInt(1,userId );
                    insertStatement.setString(2,anioegreso );
                    insertStatement.executeUpdate();
                    response.setContentType("text/html;charset=UTF-8");
                        response.sendRedirect("token.jsp");
     }
                    } catch (ClassNotFoundException | SQLException ex) {
            String error = "Error al registrar/actualizar los datos: " + ex.getMessage();
                        response.setContentType("text/html;charset=UTF-8");
                        response.sendRedirect("iniciosesion.html");
                    }    
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
