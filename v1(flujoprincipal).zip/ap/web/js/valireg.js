   function validarFormulariolog() {
    var email = document.getElementById('LEmail').value;
    var contraseña = document.getElementById('LContraseña').value;
    var formatoEmail = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;
    if (email.trim() === '' || contraseña.trim() === '') {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Por favor, completa todos los campos.'
        });
        return false;
    } else if (!formatoEmail.test(email)) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'El formato del correo electrónico no es válido.'
        });
        return false;
    } else if (email.length > 200) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'El campo de correo no puede tener más de 200 caracteres.'
        });
        return false;
    } else if (contraseña.length < 8) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'La contraseña debe tener más de 8 caracteres.'
        });
        return false;
    } else {
        Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: 'Iniciando sesion',
                showConfirmButton: false,
                timer: 2000,
                 didClose: () => {
                    document.getElementById("formlog").submit();
                }
            });
    }
}
   
   
   
   function validarFormulario() {
        var email = document.getElementById("Email").value;
        var contraseña = document.getElementById("Contraseña").value;
        var egreso = document.getElementById("egreso").value;
        var condiciones = document.getElementById("condiciones").checked;
        var numExp = /^[0-9]+$/;
        var emailExp = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (email.trim() === '' || contraseña.trim() === '' || egreso.trim() === '' || !condiciones) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Por favor, completa todos los campos y acepta los términos y condiciones.'
            });
        }else if (contraseña.length < 8) {
    Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'La contraseña debe tener al menos 8 caracteres.'
            });
        }else if (!email.match(emailExp)) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Ingresa una dirección de correo electrónico válida.'
            });
        } else if (!egreso.match(numExp)) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'El campo "Año de Egreso" solo debe contener números.'
            });
        }  else if (egreso.length !== 4) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'El campo "Año de Egreso" debe tener exactamente 4 caracteres.'
            });
        }  else if (parseInt(egreso) > new Date().getFullYear()) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'El año de egreso no puede ser mayor al año actual.'
            });
        } else if (parseInt(egreso) < new Date().getFullYear() - 3) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'El año de egreso no puede ser 3 años menor al año actual.'
            });
        } else {
            Swal.fire({
                icon: 'success',
                title: 'Éxito',
                text: 'Formulario enviado correctamente.',
                showConfirmButton: false,
                timer: 2000,
                 didClose: () => {
                    document.getElementById("regis").submit();
                }
            });
        }
    }